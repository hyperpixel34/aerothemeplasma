sudo cp zip.png application-gzip.png
sudo cp zip.png application-x-bzip-compressed-tar.png
sudo cp zip.png application-x-bzip
sudo cp zip.png application-x-gzip
sudo cp zip.png application-x-zip-compressed-fb2.png
sudo cp zip.png application-zip
sudo cp zip.png application-vnd.rar.png
sudo cp zip.png application-x-rar.png

