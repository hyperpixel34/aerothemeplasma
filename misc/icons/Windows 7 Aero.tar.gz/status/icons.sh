#!/bin/bash

ln -s network-wireless-0-flyout.png network-wireless-0-locked-flyout.png
ln -s network-wireless-20-flyout.png network-wireless-20-locked-flyout.png
ln -s network-wireless-40-flyout.png network-wireless-40-locked-flyout.png
ln -s network-wireless-60-flyout.png network-wireless-60-locked-flyout.png
ln -s network-wireless-80-flyout.png network-wireless-80-locked-flyout.png
ln -s network-wireless-100-flyout.png network-wireless-100-locked-flyout.png

ln -s network-wireless-0-flyout.png network-wireless-0-limited-flyout.png
ln -s network-wireless-20-flyout.png network-wireless-20-limited-flyout.png
ln -s network-wireless-40-flyout.png network-wireless-40-limited-flyout.png
ln -s network-wireless-60-flyout.png network-wireless-60-limited-flyout.png
ln -s network-wireless-80-flyout.png network-wireless-80-limited-flyout.png
ln -s network-wireless-100-flyout.png network-wireless-100-limited-flyout.png
